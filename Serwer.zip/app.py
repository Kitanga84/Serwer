# Pełny app.py wklejany był wcześniej — w praktyce tutaj znajdzie się kompletny kod aplikacji
